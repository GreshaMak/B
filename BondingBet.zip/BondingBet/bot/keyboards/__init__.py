from bot.keyboards import admink
from bot.keyboards import functional
from bot.keyboards import start_keyboards