TOKEN = "6967907869:AAEvIeXgEre8lyzXj4Au7YISy5eq9IVzdgg" #токен BotFather
CRYPTO_TOKEN = "198292:AAFxz6YDuzk2uKhdXd221vw3fenOS7VlQI2" #токен CreptoPay
LOG_CHANNEL = -1002213978799 #ЛОГИРОВАНИЕ
CHANNEL_BROKER = -1002213978799 #Посредник
MAIN_CHANNEL = -1002213978799 #основа
ADMINS = [1545710128] #список админов
CHECK_URL = "http://t.me/send?start=IV8QSCGd6wSR" #юрл счёта
MONEYBACK = 0 #процент манибэка от игры
