from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton



cancel_button = InlineKeyboardButton("🚫 Отмена", callback_data="cancel_operation")
cancel_k = InlineKeyboardMarkup().add(cancel_button)


menu_button = KeyboardButton('Меню')
menu_markup = ReplyKeyboardMarkup(resize_keyboard=True).add(menu_button)


menu_button_game = InlineKeyboardButton('🎲 Играть', callback_data='game')
menu_button_info = InlineKeyboardButton('ℹ️ Информация', callback_data='info')
menu_button_profile = InlineKeyboardButton('👤 Профиль', callback_data='profile')
inline_menu = InlineKeyboardMarkup().add(
        menu_button_game
    ).row(
        menu_button_profile,
        menu_button_info
    )
