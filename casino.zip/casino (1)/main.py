import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import Message
from aiogram.utils import executor
import aiosqlite
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from keyboards import *
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from datetime import datetime, timedelta
import operator
from aiocryptopay import AioCryptoPay, Networks	
from aiogram.utils.markdown import hlink
from aiogram.types import InputMediaPhoto
import random 
import math
import asyncio


#1825 строка надо заменить ссылки на поддержку канал и т.д.

API_TOKEN = '6967907869:AAEvIeXgEre8lyzXj4Au7YISy5eq9IVzdgg'
CRYPTO_PAY_TOKEN = '198292:AAFxz6YDuzk2uKhdXd221vw3fenOS7VlQI2'
# Включаем логирование, чтобы видеть сообщения об ошибках
logging.basicConfig(level=logging.INFO)

ADMINS = []

# Инициализируем бота и диспетчера
bot = Bot(token=API_TOKEN, parse_mode="HTML")
storage = MemoryStorage()

class CryproBot(StatesGroup):
    sum = State()
    currency = State()

class WithdrawState(StatesGroup):
    amount = State()

class AdminPanelState(StatesGroup):
    SEND_MESSAGE = State()
    ENTER_IMAGE = State()
    ENTER_MESSAGE = State()


dp = Dispatcher(bot, storage=storage)

async def create_tables():
    async with aiosqlite.connect("database.db") as db:
        # Создание таблицы пользователей
        await db.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, balance REAL, registration_time TEXT, is_admin INTEGER, is_ban INTEGER, reffer_id TEXT)")
        
        # Создание таблицы игр
        await db.execute("CREATE TABLE IF NOT EXISTS games (id INTEGER PRIMARY KEY, bet INTEGER, creator_id INT, game_emoji TEXT, creation_time TEXT, winner_id INT, is_open BOOL)")
        
        # Создание таблицы участников игр
        await db.execute("CREATE TABLE IF NOT EXISTS game_members (game_id INTEGER, user_id INTEGER, username TEXT)")

        await db.execute("CREATE TABLE IF NOT EXISTS vivods (id INTEGER PRIMARY KEY, user_id INTEGER, summ REAL, is_done BOOL, username TEXT)")
        
        # Создание таблицы конфигурации, если она не существует
        await db.execute("CREATE TABLE IF NOT EXISTS config (id INTEGER PRIMARY KEY, deposit_fee REAL, game_fee REAL, game_time INTEGER, min_vivod REAL)")

        # Вставка одной строки в таблицу конфигурации, если она пуста
        await db.execute("INSERT OR IGNORE INTO config (id, deposit_fee, game_fee, game_time, min_vivod) VALUES (1, 0, 0, 3600, 1)")
        
        await db.execute("CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY, payment_id INTEGER, summa REAL)")

        await db.execute("CREATE TABLE IF NOT EXISTS promo (id INTEGER PRIMARY KEY, name TEXT, summa REAL, activates INT)")

        await db.execute("CREATE TABLE IF NOT EXISTS activate_promo(id_promo INTEGER, id_user INT)")

        await db.execute("CREATE TABLE IF NOT EXISTS games_chat (id INTEGER PRIMARY KEY, bet INTEGER, creator_id INT, game_emoji TEXT, creation_time TEXT, winner_id INT, is_open BOOL, messageid INT)")

        await db.execute("CREATE TABLE IF NOT EXISTS chat_game_members (game_id INTEGER, user_id INTEGER, username TEXT)")


        await db.commit()

async def update_balance(user_id: int, amount: float):
    async with aiosqlite.connect("database.db") as db:
        # Получаем текущий баланс пользователя
        cursor = await db.execute("SELECT balance FROM users WHERE id=?", (user_id,))
        current_balance = await cursor.fetchone()

        if current_balance:
            # Обновляем баланс пользователя с учетом пополнения
            new_balance = round(float(current_balance[0]) + amount, 3)
            await db.execute("UPDATE users SET balance=? WHERE id=?", (new_balance, user_id))
            await db.commit()
        else:
            await db.execute("INSERT INTO users (id, balance, registration_time, is_admin, is_ban) VALUES (?, ?, CURRENT_TIMESTAMP, 0, 0)", (user_id, amount,))
            await db.commit()


async def add_new_payment(payment_id: int, summa: float):
    async with aiosqlite.connect("database.db") as db:
        await db.execute('''
            INSERT INTO payments (payment_id, summa)
            VALUES (?, ?)
        ''', (payment_id, summa))
        try:
            await db.commit()
        except aiosqlite.IntegrityError:
            await db.rollback()

async def select_payment(payment_id: int):
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute('SELECT * FROM payments WHERE payment_id = ?', (payment_id,))
        payment = await cursor.fetchone()
        return payment

async def delete_payment(payment_id: int):
    async with aiosqlite.connect("database.db") as db:
        await db.execute('DELETE FROM payments WHERE payment_id = ?', (payment_id,))
        await db.commit()





@dp.message_handler(commands=['dice'])
async def start(message: types.Message):
    user_id = message.from_user.id
    if message.chat.type != types.ChatType.SUPERGROUP:
        await message.reply("⛔️ Команда работает только в супер группах")
        return

    # Проверяем, был ли передан параметр start через реферальную ссылку
    if not message.get_args():
        await message.reply("⛔️ Введите ставку через пробел, пример /dice 100")
        return
    bet = message.get_args()
    try:
       bet = float(bet)
    except:
        await message.reply("⛔️ Ставка должна быть числом")
        return

    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = await cursor.fetchone()
        if user is None:
            await db.execute("INSERT INTO users (id, balance, registration_time, is_admin, is_ban, reffer_id) VALUES (?, 0, CURRENT_TIMESTAMP, 0, 0, NULL)", (user_id,))
            await db.commit()   
    if float(bet) < 0.1:
        await message.reply("⛔️ Минимальная ставка 0.1$")
        return
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT balance FROM users WHERE id = ?", (message.from_user.id,)) as cursor:
            balance = await cursor.fetchone()
    if bet > balance[0]:
        await message.reply(f"⛔️ У вас не достаточно баланса")
        return
    new_balance = round(float(balance[0]) - float(bet), 3)

    async with aiosqlite.connect("database.db") as db:
        await db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, message.from_user.id))
        await db.commit()   
        game_emoji = "🎲"
        creation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        cursor = await db.execute("INSERT INTO games_chat (bet, creator_id, game_emoji, creation_time, is_open) VALUES (?, ?, ?, ?, ?)",
                                 (round(float(bet), 3), message.from_user.id, game_emoji, creation_time, True))
        game_id = cursor.lastrowid
        players_markup = InlineKeyboardMarkup()
        players_markup.row(
            InlineKeyboardButton("👥 Подключиться", callback_data=f"chatjoin_game:{game_id}")
        )

        message = await message.reply(f"""
🎲 Новая игра!

💰 Сумма игры: {round(bet, 3)}$

👥 Игроки:
1️⃣ • @{message.from_user.username}
2️⃣ • ожидается...

🆔 #{game_id}
""", reply_markup=players_markup)







async def check_subscription(user_id, message):
    try:
        chat_member = await bot.get_chat_member(-1002024629354,user_id)
        is_subscribed = chat_member.status in ['administrator', 'member', 'creator']
    except Exception as e:  # Обработка возможных ошибок
        is_subscribed = False
        print(f"Error: {e}")

    if is_subscribed:
        return False
    else:
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [
                InlineKeyboardButton(text="🎲 Канал", url=f"https://t.me/cryptocube_off")
            ],
            [
                InlineKeyboardButton(text="✅ Проверить", callback_data="check_subscription")
            ]
        ])
        await message.answer("Вы не подписаны на канал, подпишитесь пожалуйста", reply_markup=keyboard)
        return True

@dp.callback_query_handler(lambda callback_query: callback_query.data == 'check_subscription')
async def cancel_operation(callback_query: types.CallbackQuery):
    await callback_query.answer()
    try:
        chat_member = await bot.get_chat_member(-1002024629354, callback_query.from_user.id)
        is_subscribed = chat_member.status in ['administrator', 'member','creator']
    except Exception as e:  # Обработка возможных ошибок
        is_subscribed = False
        print(f"Error: {e}")
    if is_subscribed:
        await callback_query.answer()
        menu_button = KeyboardButton('Меню')
        menu_markup = ReplyKeyboardMarkup(resize_keyboard=True).add(menu_button)
        await callback_query.message.answer("Кнопка меню", reply_markup=menu_markup)
            
        menu_button_game = InlineKeyboardButton('🎲 Играть', callback_data='game')
        menu_button_info = InlineKeyboardButton('ℹ️ Информация', callback_data='info')
        menu_button_profile = InlineKeyboardButton('👤 Профиль', callback_data='profile')
        inline_markup = InlineKeyboardMarkup().add(
             menu_button_game
        ).row(
            menu_button_profile,
            menu_button_info
        )
        await callback_query.message.answer_photo("https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg", caption="Меню", reply_markup=inline_markup)
    else:
        await callback_query.message.answer("✖️ Для начала подпишитесь")




@dp.callback_query_handler(lambda callback_query: callback_query.data == 'cancel_operation', state="*")
async def cancel_operation(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer("Операция отменена")
    await state.finish()
    await callback_query.message.edit_media(
        media=InputMediaPhoto(media="https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg"),
    )
    await callback_query.message.edit_caption(
        caption="Меню",
        reply_markup=inline_menu
    )

cancel_button = InlineKeyboardButton("🚫 Отмена", callback_data="cancel_11operation")
cancel_keyboard = InlineKeyboardMarkup().add(cancel_button)




@dp.callback_query_handler(lambda callback_query: callback_query.data == 'cancel_11operation', state="*")
async def cancel_operation(callback_query: types.CallbackQuery, state: FSMContext):
    await callback_query.answer("Операция отменена")
    await state.finish()

    # Получите информацию о сообщении
    message = callback_query.message
    chat_id = message.chat.id
    message_id = message.message_id

    # Обновите текст сообщения
    await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text="Операция отменена")


@dp.message_handler(commands=['admin'])
async def admin(message: types.Message):
    user_id = message.from_user.id

    if user_id not in ADMINS:
        return

    await message.answer("🛠️\nВыберите действие:", reply_markup=InlineKeyboardMarkup(row_width=1).add(
        InlineKeyboardButton("💸 Выводы", callback_data="withdrawns"),
        InlineKeyboardButton("📢 Рассылка", callback_data="broadcast"),
        InlineKeyboardButton("📊 Статистика", callback_data="stats"),
        InlineKeyboardButton("⚙️ Настройка промокодов", callback_data="setting_promo")

    ))



@dp.callback_query_handler(lambda query: query.data == 'setting_promo')
async def promo_settings(query: types.CallbackQuery):
    button_info = InlineKeyboardButton('ℹ️ Информация о промокодах', callback_data='promo_info')
    button_create = InlineKeyboardButton('➕ Создать промокод', callback_data='create_promo')
    
    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    inline_markup.add(button_info, button_create)
    
    await query.message.edit_reply_markup(reply_markup=inline_markup)


@dp.callback_query_handler(lambda query: query.data == 'promo_info')
async def show_promo_info(query: types.CallbackQuery):
    await query.answer()
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT id, name, summa FROM promo WHERE activates > 0")
        promos = await cursor.fetchall()

    page_number = 1
    total_pages = math.ceil(len(promos) / 10)
    
    await show_promo_page(query.message.chat.id, page_number, total_pages, promos)

async def show_promo_page(chat_id, page_number, total_pages, promos):
    start_index = (page_number - 1) * 10
    end_index = min(start_index + 10, len(promos))
    
    keyboard = []
    for i in range(start_index, end_index):
        promo_name = promos[i][1]
        promo_summa = promos[i][2]
        promo_id = promos[i][0]

        button_text = f"{promo_name} - {promo_summa}"
        keyboard.append(InlineKeyboardButton(text=button_text, callback_data=f"promo_{promo_id}"))

    inline_kb = InlineKeyboardMarkup(row_width=1)
    inline_kb.add(*keyboard)
    
    if total_pages > 1:
        navigation_buttons = []
        if page_number > 1:
            navigation_buttons.append(InlineKeyboardButton(text="<<", callback_data=f"promo_page_{page_number-1}"))
        if page_number < total_pages:
            navigation_buttons.append(InlineKeyboardButton(text=">>", callback_data=f"promo_page_{page_number+1}"))
        
        inline_kb.add(*navigation_buttons)

    await bot.send_message(chat_id, "Список промокодов:", reply_markup=inline_kb)



@dp.callback_query_handler(lambda query: query.data.startswith('promo_page_'))
async def change_promo_page(query: types.CallbackQuery):
    page_number = int(query.data.split('_')[-1])
    
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT id, name, summa FROM promo WHERE activates > 0")
        promos = await cursor.fetchall()

    total_pages = math.ceil(len(promos) / 10)
    
    await show_promo_page(query.message.chat.id, page_number, total_pages, promos)


@dp.callback_query_handler(lambda query: query.data.startswith('promo_'))
async def show_promo_info(query: types.CallbackQuery):
    await query.answer()
    promo_id = int(query.data.split('_')[1])
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT name, summa, activates FROM promo WHERE id = ?", (promo_id,))
        promo_info = await cursor.fetchone()
        
        cursor = await db.execute("SELECT COUNT(*) FROM activate_promo WHERE id_promo = ?", (promo_id,))
        activations_count = await cursor.fetchone()

    promo_name = promo_info[0]
    promo_summa = promo_info[1]
    activations = promo_info[2]
    activations_left = activations  - activations_count[0]  # Предполагается, что MAX_ACTIVATIONS - максимальное количество активаций для промокода

    text = f"Информация о промокоде:\n\nНазвание: {promo_name}\nСумма: {promo_summa}\nВсего активаций {activations}\nОсталось активаций: {activations_left}"
    
    keyboard = types.InlineKeyboardMarkup()
    keyboard.add(types.InlineKeyboardButton(text="Удалить промокод", callback_data=f"delete_promo_{promo_id}"))
    
    await bot.send_message(query.message.chat.id, text, reply_markup=keyboard)

@dp.callback_query_handler(lambda query: query.data.startswith('delete_promo_'))
async def delete_promo(query: types.CallbackQuery):
    promo_id = query.data.split('_')[-1]
    
    async with aiosqlite.connect("database.db") as db:
        await db.execute("UPDATE promo SET activates = 0 WHERE id = ?", (promo_id,))
        await db.commit()

    await bot.edit_message_text(chat_id=query.message.chat.id, message_id=query.message.message_id, text="Промокод успешно удален.")


class PromoCreationStates(StatesGroup):
    name = State()
    summa = State()
    activates = State()

@dp.callback_query_handler(lambda query: query.data == 'create_promo')
async def start_promo_creation(query: types.CallbackQuery):
    await query.answer()

    await PromoCreationStates.name.set()
    await query.message.answer("Введите название промокода:", reply_markup=cancel_keyboard)

@dp.message_handler(state=PromoCreationStates.name)
async def process_name(message: types.Message, state: FSMContext):
    name = message.text
    await state.update_data(name=name)
    await PromoCreationStates.summa.set()
    await message.answer("Введите сумму промокода (число):", reply_markup=cancel_keyboard)

@dp.message_handler(state=PromoCreationStates.summa)
async def process_summa(message: types.Message, state: FSMContext):
    try:
        summa = float(message.text)
    except ValueError:
        await message.answer("Сумма должна быть числом. Попробуйте еще раз.", reply_markup=cancel_keyboard)
        return
    await state.update_data(summa=summa)
    await PromoCreationStates.activates.set()
    await message.answer("Введите количество активаций (число):", reply_markup=cancel_keyboard)

@dp.message_handler(state=PromoCreationStates.activates)
async def process_activates(message: types.Message, state: FSMContext):
    try:
        activates = int(message.text)
    except ValueError:
        await message.answer("Количество активаций должно быть числом. Попробуйте еще раз.", reply_markup=cancel_keyboard)
        return
    data = await state.get_data()
    name = data.get('name')
    summa = data.get('summa')
    
    async with aiosqlite.connect("database.db") as db:
        await db.execute("INSERT INTO promo (name, summa, activates) VALUES (?, ?, ?)", (name, summa, activates))
        await db.commit()
    await state.finish()
    await message.answer("Промокод успешно создан и сохранен в базе данных.")

@dp.callback_query_handler(text_contains="broadcast")
async def send_message(callback_query: types.CallbackQuery, state: FSMContext):
    await bot.answer_callback_query(callback_query.id)
    await callback_query.message.answer("Введите текст рассылки:\n\nТекст\n[КНОПКА (если надо)](https://t.me/cryptocubebot)\n[КНОПКА (если надо)](https://t.me/cryptocubebot)", reply_markup=cancel_keyboard)
    await AdminPanelState.ENTER_MESSAGE.set()


@dp.message_handler(state=AdminPanelState.ENTER_MESSAGE)
async def process_message(message: types.Message, state: FSMContext):
    formatted_text = message.html_text  # Используйте html_text для сохранения форматирования
    await state.update_data(message_text=formatted_text)
    await message.answer("Есть ли картинка в рассылке? (да/нет)")
    await AdminPanelState.ENTER_IMAGE.set()


@dp.message_handler(state=AdminPanelState.ENTER_IMAGE)
async def process_image(message: types.Message, state: FSMContext):
    if message.text.lower() == "да":
        await message.answer("Пришлите картинку для рассылки")
        await AdminPanelState.SEND_MESSAGE.set()
    else:
        await message.answer("Вы уверены, что хотите отправить рассылку? (да/нет)")
        await AdminPanelState.SEND_MESSAGE.set()


@dp.message_handler(state=AdminPanelState.SEND_MESSAGE)
async def send_message_to_users(message: types.Message, state: FSMContext):
    if message.text.lower() == "да":
        data = await state.get_data()
        message_text = data.get("message_text")
        await message.answer("Рассылка запущена!")

        # Получаем все кнопки из сообщения
        button_list = []
        message_lines = message_text.split('\n')
        for line in message_lines:
            if ']' in line and '(http' in line:
                start = line.index('[') + 1
                end = line.index(']')
                link_text = line[start:end]
                link = line[line.index('(') + 1:line.index(')')]
                button = InlineKeyboardButton(link_text, url=link)
                button_list.append(button)  # Создаем инлайн клавиатуру и добавляем кнопки к ней
        keyboard = InlineKeyboardMarkup(row_width=1)
        for button in button_list:
            keyboard.add(button)

        # Удаляем ссылки из текста сообщения
        message_lines = message_text.split('\n')
        new_message_lines = []
        for line in message_lines:
            if ']' not in line or '(' not in line or ')' not in line:
                new_message_lines.append(line)
        message_text = '\n'.join(new_message_lines)
        # Отправляем сообщение с инлайн кнопками каждому пользователю
        async with aiosqlite.connect("database.db") as db:
            c = await db.cursor()
            await c.execute("SELECT id FROM users")
            users = await c.fetchall()
        good = 0
        bad = 0
        for user in users:
            try:
                await bot.send_message(user[0], message_text, parse_mode="HTML", reply_markup=keyboard)
                good += 1
            except:
                bad += 1
        await message.answer(f"Рассылка отправлена!\n\nПолучили: {good}\nНе получили: {bad}")
        await state.finish()

    else:
        await message.answer("Отправка рассылки отменена.")
        await state.finish()


@dp.message_handler(state=AdminPanelState.SEND_MESSAGE, content_types=types.ContentTypes.PHOTO)
async def send_message_to_users(message: types.Message, state: FSMContext):
    if message.photo:
        data = await state.get_data()
        message_text = data.get("message_text")
        photo_id = message.photo[0].file_id

        await message.answer("Рассылка запущена!")

        # Получаем все кнопки из сообщения
        button_list = []
        message_lines = message_text.split('\n')
        for line in message_lines:
            if ']' in line and '(http' in line:
                start = line.index('[') + 1
                end = line.index(']')
                link_text = line[start:end]
                link = line[line.index('(') + 1:line.index(')')]
                button = InlineKeyboardButton(link_text, url=link)
                button_list.append(button)
        keyboard = InlineKeyboardMarkup(row_width=1)
        for button in button_list:
            keyboard.add(button)

        # Удаляем ссылки из текста сообщения
        message_lines = message_text.split('\n')
        new_message_lines = []
        for line in message_lines:
            if ']' not in line or '(' not in line or ')' not in line:
                new_message_lines.append(line)
        message_text = '\n'.join(new_message_lines)

        # Отправляем сообщение с инлайн кнопками и картинкой каждому пользователю
        async with aiosqlite.connect("database.db") as db:
            c = await db.cursor()
            await c.execute("SELECT id FROM users")
            users = await c.fetchall()
        good = 0
        bad = 0
        for user in users:
            try:
                await bot.send_photo(user[0], photo=photo_id, caption=message_text, reply_markup=keyboard,
                                     parse_mode="HTML")
                good += 1
            except Exception as e:
                bad += 1
                print(e)
        await message.answer(f"Рассылка отправлена!\n\nПолучили: {good}\nНе получили: {bad}")
        await state.finish()

    else:
        await message.answer(f"Шото сломалось")
        await state.finish()





    
@dp.callback_query_handler(lambda query: query.data == 'stats')
async def process_statistics_button(callback_query: types.CallbackQuery):
    async with aiosqlite.connect("database.db") as db:
        # Получаем количество пользователей
        users_count = await db.execute("SELECT COUNT(*) FROM users")
        users_count = await users_count.fetchone()

        # Получаем количество сыгранных игр
        games_count = await db.execute("SELECT COUNT(*) FROM games")
        games_count = await games_count.fetchone()

        # Получаем общую сумму выводов
        total_withdrawals = await db.execute("SELECT SUM(summ) FROM vivods WHERE is_done = 1")
        total_withdrawals = await total_withdrawals.fetchone()

        # Получаем общую сумму ставок
        total_bets = await db.execute("SELECT SUM(bet) FROM games")
        total_bets = await total_bets.fetchone()

        statistics_text = f"Статистика:\n\nКоличество пользователей: {users_count[0]}\nКоличество сыгранных игр: {int(games_count[0])}\nОбщая сумма выводов: {round(float(total_withdrawals[0]), 3)}\nОбщая сумма ставок: {round(float(total_bets[0]),3)}"
        await callback_query.answer()
        await bot.send_message(callback_query.from_user.id, statistics_text)






async def check_balance_and_transfer(user_id, amount, withdrawal_id):
    spend_id = random.randint(1000000, 99999999)
    cryptopay = AioCryptoPay(CRYPTO_PAY_TOKEN)

    balance = await cryptopay.get_balance()
    for b in balance:
        if b.currency_code == 'USDT':
            usdt_balance = b.available
            break 
    #amount = await get_crypto_bot_sum(amount, "USDT")
    if usdt_balance >= amount:
        await cryptopay.transfer(user_id=user_id, asset="USDT", amount=amount, spend_id=spend_id, comment="Выплата с бота @cryptocubebot")
        await cryptopay.close()

        async with aiosqlite.connect("database.db") as db:
            await db.execute("UPDATE vivods SET is_done = ? WHERE id = ?", (True, withdrawal_id))
            await db.commit()
        return True
    else:
        await cryptopay.close()
        return False


@dp.callback_query_handler(lambda query: query.data.startswith('send_'))
async def process_send_button(callback_query: types.CallbackQuery):
    withdrawal_id = callback_query.data.split('_')[1]  # Получаем ID вывода
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT user_id, summ, is_done FROM vivods WHERE id = ?", (withdrawal_id,))
        row = await cursor.fetchone()
    user_id = row[0]
    amount = row[1]
    is_done = row[2]
    if is_done:
        await callback_query.message.answer("Заявка уже выплачена")
        return

    try:
        send = await check_balance_and_transfer(user_id, amount, withdrawal_id)
        if send:
            await callback_query.message.answer("Средства успешно отправлены")
            try:
                await bot.send_message(user_id, f"Успешно выплачено {amount}$ на @CryptoBot")
            except:
                pass
        else:
            await callback_query.message.answer("На балансе счета не достаточно средств")
    except Exception as e:
        print(e)
        await callback_query.message.answer("Произошла ошибка, возможно пользователь не зарегистрирован в @cryptobot")
    await callback_query.answer()


@dp.callback_query_handler(lambda query: query.data.startswith('reject_'))
async def process_send_button(callback_query: types.CallbackQuery):
    withdrawal_id = callback_query.data.split('_')[1]  # Получаем ID вывода
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT user_id, summ, is_done FROM vivods WHERE id = ?", (withdrawal_id,))
        row = await cursor.fetchone()
    user_id = row[0]
    amount = row[1]
    is_done = row[2]
    if is_done:
        await callback_query.message.answer("Заявка уже выплачена")
        return
    async with aiosqlite.connect("database.db") as db:
        await db.execute("UPDATE vivods SET is_done = ? WHERE id = ?", (True, withdrawal_id))
        await db.commit()

    await callback_query.message.answer("Заявка успешно отклонена")
    try:
        await bot.send_message(user_id, f"Ваша заявка на вывод {amount}р на @CryptoBot отклонена, возможно вы не зарегистрированы в @Cryptobot")
    except:
        pass

    await callback_query.answer()


@dp.callback_query_handler(lambda query: query.data.startswith('withdrawn_'))
async def process_withdrawn(callback_query: types.CallbackQuery):
    withdrawal_id = int(callback_query.data.split('_')[1])
    await callback_query.answer()
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT * FROM vivods WHERE id = ?", (withdrawal_id,))
        withdrawal = await cursor.fetchone()
    
    if withdrawal:
        message_text = f"Информация о выводе:\nID: {withdrawal[0]}\nСумма: {withdrawal[2]}\nСтатус: {'Выполнено' if withdrawal[3] else 'Не выполнено'}\nИмя пользователя: @{withdrawal[4]}"
        
        keyboard = types.InlineKeyboardMarkup()
        keyboard.add(types.InlineKeyboardButton(text="Отправить", callback_data=f"send_{withdrawal_id}"))
        keyboard.add(types.InlineKeyboardButton(text="Отклонить", callback_data=f"reject_{withdrawal_id}"))
        
        await bot.send_message(callback_query.from_user.id, message_text, reply_markup=keyboard)
    else:
        await bot.send_message(callback_query.from_user.id, "Вывод не найден в базе данных.")

@dp.callback_query_handler(lambda query: query.data == "withdrawns")
async def show_withdrawns(call: types.CallbackQuery):
    user_id = call.from_user.id

    if user_id not in ADMINS:
        return

    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT id, summ FROM vivods WHERE is_done = 0")
        withdrawns = await cursor.fetchall()

    page_size = 10
    total_pages = (len(withdrawns) + page_size - 1) // page_size

    page_number = 1
    offset = (page_number - 1) * page_size
    withdrawns_page = withdrawns[offset:offset + page_size]
    buttons = []
    for withdrawal in withdrawns_page:
        buttons.append([
            InlineKeyboardButton(f"ID: {withdrawal[0]}, Сумма: {withdrawal[1]}", callback_data=f"withdrawn_{withdrawal[0]}")
        ])

    pagination_buttons = []
    if total_pages > 1:
        if page_number > 1:
            pagination_buttons.append(
                InlineKeyboardButton("⬅️ Назад", callback_data=f"withdrawns_page_{page_number - 1}")
            )
        if page_number < total_pages:
            pagination_buttons.append(
                InlineKeyboardButton("➡️ Вперед", callback_data=f"withdrawns_page_{page_number + 1}")
            )

    buttons.append(pagination_buttons)    
    await call.message.edit_text("Выберите вывод:", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


@dp.callback_query_handler(lambda query: query.data.startswith("withdrawns_page_"))
async def change_withdrawns_page(call: types.CallbackQuery):
    user_id = call.from_user.id
    if user_id not in ADMINS:
        return

    page_number = int(call.data.split("_")[-1])

    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT id, summ FROM vivods WHERE is_done = 0")
        withdrawns = await cursor.fetchall()

    page_size = 10
    total_pages = (len(withdrawns) + page_size - 1) // page_size

    if page_number < 1 or page_number > total_pages:
        return

    offset = (page_number - 1) * page_size
    withdrawns_page = withdrawns[offset:offset + page_size]

    buttons = []
    for withdrawal in withdrawns_page:
        buttons.append([
            InlineKeyboardButton(f"ID: {withdrawal[0]}, Сумма: {withdrawal[1]}", callback_data=f"withdrawn_{withdrawal[0]}")
        ])

    pagination_buttons = []
    if total_pages > 1:
        if page_number > 1:
            pagination_buttons.append(
                InlineKeyboardButton("⬅️ Назад", callback_data=f"withdrawns_page_{page_number - 1}")
            )
        if page_number < total_pages:
            pagination_buttons.append(
                InlineKeyboardButton("➡️ Вперед", callback_data=f"withdrawns_page_{page_number + 1}")
            )

    buttons.append(pagination_buttons)      
    await call.message.edit_text("Выберите вывод:", reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons))


@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    user_id = message.from_user.id
    
    # Проверяем, был ли передан параметр start через реферальную ссылку
    if message.get_args():
        referrer_id = message.get_args()
    else:
        referrer_id = None
    
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = await cursor.fetchone()
        
        if user is None:
            if referrer_id:
                await db.execute("INSERT INTO users (id, balance, registration_time, is_admin, is_ban, reffer_id) VALUES (?, 0, CURRENT_TIMESTAMP, 0, 0, ?)", (user_id, referrer_id))
            else:
                await db.execute("INSERT INTO users (id, balance, registration_time, is_admin, is_ban, reffer_id) VALUES (?, 0, CURRENT_TIMESTAMP, 0, 0, NULL)", (user_id,))
            await db.commit()    
        is_not_sub = await check_subscription(message.from_user.id, message) 
        if is_not_sub:
            return       
        menu_button = KeyboardButton('Меню')
        menu_markup = ReplyKeyboardMarkup(resize_keyboard=True).add(menu_button)
        await message.answer("Кнопка меню", reply_markup=menu_markup)
            
        menu_button_game = InlineKeyboardButton('🎲 Играть', callback_data='game')
        menu_button_info = InlineKeyboardButton('ℹ️ Информация', callback_data='info')
        menu_button_profile = InlineKeyboardButton('👤 Профиль', callback_data='profile')
        inline_markup = InlineKeyboardMarkup().add(
             menu_button_game
        ).row(
            menu_button_profile,
            menu_button_info
        )
        await message.answer_photo("https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg", caption="Меню", reply_markup=inline_markup)


@dp.callback_query_handler(lambda query: query.data in ['game', 'update'])
async def show_info(query: types.CallbackQuery):
    await query.answer()
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT id, game_emoji, bet FROM games WHERE is_open = 1 ORDER BY id LIMIT 10") as cursor:
            games = await cursor.fetchall()

        markup = InlineKeyboardMarkup()
        if not games:
            markup.row(
                InlineKeyboardButton(f"❌ Игр нет", callback_data=f"notgames")
            )
        else:
            user_id = query.from_user.id
            for game in games:
                async with db.execute("SELECT COUNT(*) FROM game_members WHERE game_id = ? AND user_id = ?", (game[0], user_id)) as member_cursor:
                    member_count = await member_cursor.fetchone()

                if member_count[0]:
                    player_emoji = "👤"
                else:
                    player_emoji = ""

                markup.row(
                    InlineKeyboardButton(f"{game[1]} №{game[0]} {game[2]} $ {player_emoji}", callback_data=f"info_game:{game[0]}")
                )

        markup.row(
            InlineKeyboardButton("🔄 Обновить", callback_data="update"),
  #          InlineKeyboardButton("🗂 Мои игры", callback_data="my_games")
        )

        if len(games) == 10:
            markup.row(
                InlineKeyboardButton("Далее ➡️", callback_data="next_page:2")
            )

        markup.row(
            InlineKeyboardButton("➕ Создать игру", callback_data="create_game"),
            InlineKeyboardButton("📊 Статистика", callback_data="userstat")

        )

        markup.row(
            InlineKeyboardButton("🔝 В меню", callback_data="back_to_menu")
        )
        try:

            await query.message.edit_media(
                media=InputMediaPhoto(media="https://0x0.st/s/iH4nIUH2ocVxXSh8yfPzeQ/HF2O.jpg"),
            )
            await query.message.edit_caption(
                caption="🎲 Игры",
                reply_markup=markup
            )

        except Exception as e:
            print(e)
            pass

async def get_top_players_stats():
    async with aiosqlite.connect("database.db") as db:
        # Рассчитываем суммы ставок каждого игрока за день
        sql_query = """
            SELECT gm.username, SUM(g.bet) AS total_bet
            FROM games g
            INNER JOIN game_members gm ON g.id = gm.game_id
            WHERE g.creation_time >= ? AND g.winner_id IS NOT NULL
            GROUP BY gm.username
            ORDER BY total_bet DESC
        """
        
        # За день
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        daily_stats = await db.execute_fetchall(sql_query, (today.strftime("%Y-%m-%d %H:%M:%S"),))

        # За неделю
        week_ago = today - timedelta(days=7)
        weekly_stats = await db.execute_fetchall(sql_query, (week_ago.strftime("%Y-%m-%d %H:%M:%S"),))

        # За все время
        all_time_stats = await db.execute_fetchall("""
            SELECT gm.username, SUM(g.bet) AS total_bet
            FROM games g
            INNER JOIN game_members gm ON g.id = gm.game_id
            WHERE g.winner_id IS NOT NULL
            GROUP BY gm.username
            ORDER BY total_bet DESC
        """)

        # Генерация текста статистики
        result_text = "📊 Статистика\n\n"
        
        # Добавляем статистику за день
        result_text += "👤 За день:\n"
        result_text += generate_top_players_text(daily_stats)
        
        # Добавляем статистику за неделю
        result_text += "\n👤 За неделю:\n"
        result_text += generate_top_players_text(weekly_stats)

        # Добавляем статистику за все время
        result_text += "\n👤 За все время:\n"
        result_text += generate_top_players_text(all_time_stats)
        
        result_text += "\nℹ️ В статистику входят суммы ставок"
        
        return result_text

def generate_top_players_text(stats):
    text = ""
    place_emojis = ["🥇", "🥈", "🥉"]
    
    for i, stat in enumerate(stats[:3]):
        emoji = place_emojis[i]
        username = stat[0]
        total_bet = stat[1]
        
        text += f"{emoji} @{username} [{float(round(total_bet, 3))} $]\n"
    
    return text


@dp.callback_query_handler(lambda query: query.data.startswith('userstat'))
async def userstata(callback_query: types.CallbackQuery):
    is_not_sub = await check_subscription(callback_query.from_user.id, callback_query.message) 
    if is_not_sub:
        return   

    menu_button_profile = InlineKeyboardButton('⬅️ Назад', callback_data='back_to_menu')
    inline_markup = InlineKeyboardMarkup().add(
        menu_button_profile,
    )
    formatted_stats = await get_top_players_stats()
    await callback_query.message.edit_caption(caption=formatted_stats, reply_markup=inline_markup)


@dp.callback_query_handler(lambda query: query.data.startswith('next_page'))
async def next_page(query: types.CallbackQuery):

    await query.answer()
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    page_number = int(query.data.split(":")[1])
    offset = (page_number - 1) * 10

    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT id, game_emoji, bet FROM games WHERE is_open = 1 ORDER BY id LIMIT 10 OFFSET ?", (offset,)) as cursor:
            games = await cursor.fetchall()

        markup = InlineKeyboardMarkup()
        if not games:
            markup.row(
                InlineKeyboardButton(f"❌ Игр нет", callback_data=f"notgames")
            )
        else:
            user_id = query.from_user.id
            for game in games:
                async with db.execute("SELECT COUNT(*) FROM game_members WHERE game_id = ? AND user_id = ?", (game[0], user_id)) as member_cursor:
                    member_count = await member_cursor.fetchone()

                if member_count[0]:
                    player_emoji = "👤"
                else:
                    player_emoji = ""

                markup.row(
                    InlineKeyboardButton(f"{game[1]} №{game[0]} {game[2]} $ {player_emoji}", callback_data=f"info_game:{game[0]}")
                )

        markup.row(
            InlineKeyboardButton("🔄 Обновить", callback_data="update"),
        )

        markup.row(
            InlineKeyboardButton("⬅️ Назад", callback_data=f"prev_page:{page_number}"),
            InlineKeyboardButton("➡️ Вперед", callback_data=f"next_page:{page_number+1}")
        )
        markup.row(
            InlineKeyboardButton("➕ Создать игру", callback_data="create_game"),
            InlineKeyboardButton("📊 Статистика", callback_data="userstat")

        )

        markup.row(
            InlineKeyboardButton("🔝 В меню", callback_data=f"back_to_menu"),
        )


        try:
            await query.message.edit_caption(caption=f"🎲 Игры (страница {page_number})", reply_markup=markup)
        except:
            pass

@dp.callback_query_handler(lambda query: query.data.startswith('prev_page'))
async def prev_page(query: types.CallbackQuery):
    await query.answer()
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    page_number = int(query.data.split(":")[1])
    if page_number <= 1:
        return  
    offset = (page_number - 2) * 10

    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT id, game_emoji, bet FROM games WHERE is_open = 1 ORDER BY id LIMIT 10 OFFSET ?", (offset,)) as cursor:
            games = await cursor.fetchall()

        markup = InlineKeyboardMarkup()
        if not games:
            markup.row(
                InlineKeyboardButton(f"❌ Игр нет", callback_data=f"notgames")
            )
        else:
            user_id = query.from_user.id
            for game in games:
                async with db.execute("SELECT COUNT(*) FROM game_members WHERE game_id = ? AND user_id = ?", (game[0], user_id)) as member_cursor:
                    member_count = await member_cursor.fetchone()

                if member_count[0]:
                    player_emoji = "👤"
                else:
                    player_emoji = ""

                markup.row(
                    InlineKeyboardButton(f"{game[1]} №{game[0]} {game[2]} $ {player_emoji}", callback_data=f"info_game:{game[0]}")
                )
        markup.row(
            InlineKeyboardButton("🔄 Обновить", callback_data="update"),
        )

        markup.row(
            InlineKeyboardButton("⬅️ Назад", callback_data=f"prev_page:{page_number-1}"),
            InlineKeyboardButton("➡️ Вперед", callback_data=f"next_page:{page_number}")
        )
        markup.row(
            InlineKeyboardButton("➕ Создать игру", callback_data="create_game")
        )

        markup.row(
            InlineKeyboardButton("🔝 В меню", callback_data=f"back_to_menu"),
        )

        try:
            await query.message.edit_caption(caption=f"🎲 Игры (страница {page_number-1})", reply_markup=markup)
        except:
            pass


@dp.callback_query_handler(lambda query: query.data.startswith('info_game:'), state='*')
async def show_game_info(query: types.CallbackQuery):
    game_id = int(query.data.split(':')[1])
    user_id = query.from_user.id
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   


    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT bet, creator_id, game_emoji, is_open FROM games WHERE id = ?", (game_id,)) as cursor:
            game_info = await cursor.fetchone()
        
        if not game_info:
            return
        bet = game_info[0]
        creator_id = game_info[1]
        game_emoji = game_info[2]
        is_open = game_info[3]

        if not is_open:
            await show_info(query)
            return


        players_markup = InlineKeyboardMarkup()


        if user_id == creator_id:
            players_markup.row(
                InlineKeyboardButton("❌ Удалить игру", callback_data=f"delete_game:{game_id}")
            )
        else:
            players_markup.row(
                InlineKeyboardButton("👥 Подключиться", callback_data=f"join_game:{game_id}")
            )
        players_markup.row(
            InlineKeyboardButton("⬅️ Назад", callback_data=f"game")
        )

        game_info_text = f"🎲 GAMES №{game_id}\n\n💰 Ставка: {bet} $\n\n👥 Игроки:"
        
        async with db.execute("SELECT user_id, username FROM game_members WHERE game_id = ?", (game_id,)) as player_cursor:
            players = await player_cursor.fetchall()

        for idx, player in enumerate(players, start=1):
            game_info_text += f"\n{idx}⃣ - @{player[1]}"   
        game_info_text += f"\n{len(players)+1}⃣ - Ожидание..."     
        await query.message.edit_caption(caption=game_info_text, reply_markup=players_markup)

@dp.callback_query_handler(lambda query: query.data.startswith('join_game:'))
async def join_game(callback_query: types.CallbackQuery):
    is_not_sub = await check_subscription(callback_query.from_user.id, callback_query.message) 
    if is_not_sub:
        return   

    game_id = callback_query.data.split(":")[1]
    await callback_query.answer()
    # Check if the player has sufficient balance for the game
    async with aiosqlite.connect("database.db") as db:

        async with db.execute("SELECT is_open FROM games WHERE id = ?", (game_id,)) as player_cursor:
            game = await player_cursor.fetchall()
            print(game)
            if game and game[0][0] == 0:
                await show_info(callback_query)
                await callback_query.message.answer("Игра уже была закрыта")
                return

        async with db.execute("SELECT balance FROM users WHERE id = ?", (callback_query.from_user.id,)) as balance_cursor:
            user_balance = await balance_cursor.fetchone()
            cursor = await db.execute("SELECT bet, creator_id, winner_id FROM games WHERE id = ?", (game_id,))
            game_info = await cursor.fetchone()
            bet = game_info[0]

            # Assuming the bet amount for the game is stored in a variable called 'bet_amount'
            if user_balance and user_balance[0] >= bet:
                await db.execute("UPDATE users SET balance = balance - ? WHERE id = ?", (bet, callback_query.from_user.id))
                await db.execute("INSERT INTO game_members (game_id, user_id, username) VALUES (?, ?, ?)", (game_id, callback_query.from_user.id, callback_query.from_user.username))
                await db.execute("UPDATE games SET is_open = 0 WHERE id = ?", (game_id,))
                await db.commit()
            else:
                await callback_query.message.answer("Недостаточно средств для участия в игре")
                return
        async with db.execute("SELECT creator_id FROM games WHERE id = ?", (game_id,)) as opponent_cursor:
            opponent = await opponent_cursor.fetchone()
        async with db.execute("SELECT username FROM game_members WHERE game_id = ? AND user_id = ?", (game_id, opponent[0],)) as players_cursor:
            players = await players_cursor.fetchall()
            second_player_name = players[0][0]
        async with db.execute("SELECT game_fee FROM config WHERE id = 1") as cursor:
            config = await cursor.fetchone()
            deposit_fee = config[0]
            deposit_fee = deposit_fee / 100
            print(deposit_fee)
            amount_after_fee = bet - (bet * deposit_fee)
            print(amount_after_fee)
    await callback_query.message.answer("Вы присоединились к игре")
    await bot.send_message(opponent[0], f"К вам присоединился игрок @{callback_query.from_user.username}")
    await callback_query.message.answer("Вы бросаете кубик")

    first_player_dice_value = await bot.send_dice(callback_query.from_user.id, emoji="🎲")

    await bot.send_message(opponent[0], f"Ваш противник @{callback_query.from_user.username} бросил кубик")

    await bot.forward_message(opponent[0], callback_query.from_user.id, first_player_dice_value.message_id)

    await asyncio.sleep(2)
    await bot.send_message(opponent[0], f"Вы бросаете кубик")
    second_player_dice_value = await bot.send_dice(opponent[0], emoji="🎲")
    await bot.send_message(callback_query.from_user.id, "Ваш противник бросает кубик")

    await bot.forward_message(callback_query.from_user.id,opponent[0], second_player_dice_value.message_id)


    await asyncio.sleep(2)
    
    first_player_dice_value = first_player_dice_value.dice.value
    second_player_dice = second_player_dice_value.dice.value




    updated_bet = amount_after_fee * 2

    if first_player_dice_value  > second_player_dice:
        await bot.send_message(callback_query.from_user.id, "🎊 Вы победили!\n💸 Средства зачислены на баланс")
        await add_referrer_bonus(callback_query.from_user.id, bet)
        await add_referrer_bonus(opponent[0], bet)

        await update_balance(callback_query.from_user.id, updated_bet)
        revansh = InlineKeyboardButton(f'🎲 Реванш {round(float(bet)*2.5, 3)}$', callback_data=f'revansh:{round(float(bet)*2.5, 3)}:{callback_query.from_user.id}')
        inline_menu = InlineKeyboardMarkup().add(
            revansh 
        )
        await bot.send_message(opponent[0], f"😭 Вы проиграли, победитель: @{callback_query.from_user.username}\n\nВы можете попробовать взять реванш со ставкой х2.5", reply_markup=inline_menu)
        async with aiosqlite.connect("database.db") as db:
            await db.execute("UPDATE games SET winner_id = ? WHERE id = ?", (callback_query.from_user.id, game_id,))
            await db.commit()


    elif first_player_dice_value  < second_player_dice:
        await add_referrer_bonus(callback_query.from_user.id, bet)
        await add_referrer_bonus(opponent[0], bet)

        await update_balance(opponent[0], updated_bet)
        await bot.send_message(opponent[0], f"🎊 Вы победили!\n💸 Средства зачислены на баланс")
        revansh = InlineKeyboardButton(f'🎲 Реванш {round(float(bet)*2.5, 3)}$', callback_data=f'revansh:{round(float(bet)*2.5, 3)}:{opponent[0]}')
        inline_menu = InlineKeyboardMarkup().add(
            revansh 
        )

        await bot.send_message(callback_query.from_user.id, f"😭 Вы проиграли, победитель: @{second_player_name}\n\nВы можете попробовать взять реванш со ставкой х2.5", reply_markup=inline_menu)
        async with aiosqlite.connect("database.db") as db:
            await db.execute("UPDATE games SET winner_id = ? WHERE id = ?", (opponent[0], game_id,))
            await db.commit()

    else:
        await update_balance(opponent[0], bet)
        await update_balance(callback_query.from_user.id, bet)
        await bot.send_message(callback_query.from_user.id, "Ничья, средства возвращены!")
        await bot.send_message(opponent[0], "Ничья, средства возвращены!")
        async with aiosqlite.connect("database.db") as db:
            await db.execute("UPDATE games SET winner_id = ? WHERE id = ?", (0, game_id,))
            await db.commit()

@dp.callback_query_handler(lambda query: query.data.startswith('revansh:'))
async def handle_revansh(callback: types.CallbackQuery):
    data = callback.data.split(':')
    bet = float(data[1])
    opponent_id = int(data[2])
    await bot.delete_message(chat_id=callback.message.chat.id, message_id=callback.message.message_id)
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT balance FROM users WHERE id = ?", (callback.from_user.id,)) as cursor:
            balance = await cursor.fetchone()
        async with db.execute("SELECT balance FROM users WHERE id = ?", (opponent_id,)) as cursor:
            balance_opponent = await cursor.fetchone()

        if float(bet) > float(balance[0]):  
            await callback.message.answer("❌ Недостаточно средств для указанной ставки.")
        elif float(bet) > float(balance_opponent[0]):  
            await callback.message.answer("❌ У оппонента недостаточно средств для указанной ставки.")
        else:
            await callback.message.answer("Кнопка меню", reply_markup=menu_markup)


            new_balance = round(float(balance[0]) - float(bet), 3)
            await db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, callback.from_user.id))

            # Create a new game in the games table
            game_emoji = "🎲"
            creation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor = await db.execute("INSERT INTO games (bet, creator_id, game_emoji, creation_time, is_open) VALUES (?, ?, ?, ?, ?)",
                            (float(bet), callback.from_user.id, game_emoji, creation_time, True))

            # Get the last inserted row id for the game
            game_id = cursor.lastrowid

            # Add the user as the first player in the game_members table
            await db.execute("INSERT INTO game_members (game_id, user_id, username) VALUES (?, ?, ?)",
                            (game_id, callback.from_user.id, callback.from_user.username))

            await db.commit()
            user_id = callback.from_user.id
            async with db.execute("SELECT bet, creator_id, game_emoji, is_open FROM games WHERE id = ?", (game_id,)) as cursor:
                game_info = await cursor.fetchone()
        
            if not game_info:
                return
            bet = game_info[0]
            creator_id = game_info[1]
            game_emoji = game_info[2]
            is_open = game_info[3]
            players_markup = InlineKeyboardMarkup()
            if user_id == creator_id:
                players_markup.row(
                    InlineKeyboardButton("❌ Удалить игру", callback_data=f"delete_game:{game_id}")
                )
            else:
                players_markup.row(
                    InlineKeyboardButton("👥 Подключиться", callback_data=f"join_game:{game_id}")
                )
            players_markup.row(
                InlineKeyboardButton("⬅️ Назад", callback_data=f"game")
            )

            game_info_text = f"🎲 GAMES №{game_id}\n\n💰 Ставка: {bet} $\n\n👥 Игроки:"
        
            async with db.execute("SELECT user_id, username FROM game_members WHERE game_id = ?", (game_id,)) as player_cursor:
                players = await player_cursor.fetchall()

            for idx, player in enumerate(players, start=1):
                game_info_text += f"\n{idx}⃣ - @{player[1]}"   
            game_info_text += f"\n{len(players)+1}⃣ - Ожидание..."     
            await callback.message.answer_photo(
               photo='https://0x0.st/s/iH4nIUH2ocVxXSh8yfPzeQ/HF2O.jpg',
               caption=game_info_text,
               reply_markup=players_markup
            )
            await callback.message.answer("💸 Ожидаем противника.")
            players_markup = InlineKeyboardMarkup()
            players_markup.row(
                InlineKeyboardButton("👥 Подключиться", callback_data=f"join_game:{game_id}")
            )
            players_markup.row(
                InlineKeyboardButton("⬅️ Назад", callback_data=f"game")
            )

            try:
                game_info_text = f"У вас запросили реванш\n🎲 GAMES №{game_id}\n\n💰 Ставка: {bet} $\n\n👥 Игроки:"
                for idx, player in enumerate(players, start=1):
                    game_info_text += f"\n{idx}⃣ - @{player[1]}"   
                game_info_text += f"\n{len(players)+1}⃣ - Ожидание..."     
                await bot.send_photo(
                   chat_id=opponent_id,
                   photo='https://0x0.st/s/iH4nIUH2ocVxXSh8yfPzeQ/HF2O.jpg',
                   caption=game_info_text,
                   reply_markup=players_markup
                )
            except:
                pass 





async def add_referrer_bonus(user_id: int, amount: float):
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT reffer_id FROM users WHERE id = ?", (user_id,))
        referrer_id = await cursor.fetchone()
        amount_after_fee = round(amount * 0.01, 3)
        if referrer_id[0]:
            cursor = await db.execute("SELECT balance FROM users WHERE id = ?", (int(referrer_id[0]),))
            referrer_balance = await cursor.fetchone()
            if referrer_balance:
                await update_balance(int(referrer_id[0]), amount_after_fee)
                try:
                    await bot.send_message(referrer_id[0], f"🎁 Вы получили бонус благодаря рефералу +{amount_after_fee}$")
                except:
                    pass

@dp.callback_query_handler(lambda query: query.data.startswith('delete_game'))
async def delete_game(callback_query: types.CallbackQuery):
    game_id = callback_query.data.split(":")[1]
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT is_open FROM games WHERE id = ?", (game_id,)) as player_cursor:
            game = await player_cursor.fetchall()
            print(game)

            if game and game[0][0] == 0:
                await show_info(callback_query)
                await callback_query.message.answer("Игра уже была закрыта")

            else:
                await db.execute("UPDATE games SET is_open = 0 WHERE id = ?", (game_id,))
                await db.commit()
                cursor = await db.execute("SELECT bet, creator_id, winner_id FROM games WHERE id = ?", (game_id,))
                game_info = await cursor.fetchone()
                bet = game_info[0]
                await update_balance(callback_query.from_user.id, bet)

                await show_info(callback_query)
                await callback_query.message.answer("Игра удалена")


# Добавьте обработчики для кнопок player, delete_game и join_game здесь


class CreateGameState(StatesGroup):
    GetStake = State()





@dp.callback_query_handler(lambda query: query.data == 'create_game')
async def create_game(callback_query: types.CallbackQuery, state: FSMContext):
    is_not_sub = await check_subscription(callback_query.from_user.id, callback_query.message) 
    if is_not_sub:
        return   

    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT balance FROM users WHERE id = ?", (callback_query.from_user.id,)) as cursor:
            balance = await cursor.fetchone()
    print(balance[0])
    if float(balance[0]) < 0.1:
        await callback_query.answer("❌ У вас недостаточно средств для создания игры (мин. 0.1$).", show_alert=True)
        return
    await callback_query.answer()

    await callback_query.message.answer("💰 Введите ставку (в $):", reply_markup=cancel_keyboard)
    await CreateGameState.GetStake.set()


@dp.message_handler(state=CreateGameState.GetStake)
async def get_stake(message: types.Message, state: FSMContext):
    stake = message.text
    
    # Check if the input is a valid number
    try:
        stake_amount = float(stake)
    except ValueError:
        await message.answer("❌ Пожалуйста, введите числовое значение для ставки.", reply_markup=cancel_keyboard)
        return
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT balance FROM users WHERE id = ?", (message.from_user.id,)) as cursor:
            balance = await cursor.fetchone()

        if float(stake) < 0.1:  
            await message.answer("❌ Мин. ставка 0.1$", reply_markup=cancel_k)

        elif float(stake) > float(balance[0]):  
            await message.answer("❌ Недостаточно средств для указанной ставки.", reply_markup=cancel_keyboard)

        else:
            await message.answer("Кнопка меню", reply_markup=menu_markup)


            new_balance = round(float(balance[0]) - float(stake), 3)
            await db.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, message.from_user.id))

            # Create a new game in the games table
            game_emoji = "🎲"
            creation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            cursor = await db.execute("INSERT INTO games (bet, creator_id, game_emoji, creation_time, is_open) VALUES (?, ?, ?, ?, ?)",
                            (float(stake), message.from_user.id, game_emoji, creation_time, True))

            # Get the last inserted row id for the game
            game_id = cursor.lastrowid

            # Add the user as the first player in the game_members table
            await db.execute("INSERT INTO game_members (game_id, user_id, username) VALUES (?, ?, ?)",
                            (game_id, message.from_user.id, message.from_user.username))

            await db.commit()
            await state.finish()
            user_id = message.from_user.id
            async with db.execute("SELECT bet, creator_id, game_emoji, is_open FROM games WHERE id = ?", (game_id,)) as cursor:
                game_info = await cursor.fetchone()
        
            if not game_info:
                return
            bet = game_info[0]
            creator_id = game_info[1]
            game_emoji = game_info[2]
            is_open = game_info[3]
            players_markup = InlineKeyboardMarkup()
            if user_id == creator_id:
                players_markup.row(
                    InlineKeyboardButton("❌ Удалить игру", callback_data=f"delete_game:{game_id}")
                )
            else:
                players_markup.row(
                    InlineKeyboardButton("👥 Подключиться", callback_data=f"join_game:{game_id}")
                )
            players_markup.row(
                InlineKeyboardButton("⬅️ Назад", callback_data=f"game")
            )

            game_info_text = f"🎲 GAMES №{game_id}\n\n💰 Ставка: {bet} $\n\n👥 Игроки:"
        
            async with db.execute("SELECT user_id, username FROM game_members WHERE game_id = ?", (game_id,)) as player_cursor:
                players = await player_cursor.fetchall()

            for idx, player in enumerate(players, start=1):
                game_info_text += f"\n{idx}⃣ - @{player[1]}"   
            game_info_text += f"\n{len(players)+1}⃣ - Ожидание..."     
            await message.answer_photo(
               photo='https://0x0.st/s/iH4nIUH2ocVxXSh8yfPzeQ/HF2O.jpg',
               caption=game_info_text,
               reply_markup=players_markup
            )
            await message.answer("💸 Ставка принята.")

@dp.message_handler(text='Меню')
async def start(message: types.Message):
    is_not_sub = await check_subscription(message.from_user.id, message) 
    if is_not_sub:
        return   

    user_id = message.from_user.id
    
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = await cursor.fetchone()
        
        if user is None:
            await db.execute("INSERT INTO users (id, balance, registration_time, is_admin, is_ban) VALUES (?, 0, CURRENT_TIMESTAMP, 0, 0)", (user_id,))
            await db.commit()
        await message.answer("Кнопка меню", reply_markup=menu_markup)
        await message.answer_photo("https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg", caption="Меню", reply_markup=inline_menu)

@dp.callback_query_handler(lambda query: query.data == 'back_to_menu')
async def back_to_menu(query: types.CallbackQuery):
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    await query.message.edit_media(
        media=InputMediaPhoto(media="https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg"),
    )
    await query.message.edit_caption(
        caption="Меню",
        reply_markup=inline_menu
    )


@dp.callback_query_handler(lambda callback_query: callback_query.data == 'withdraw', state="*")
async def withdraw(callback_query: types.CallbackQuery, state: FSMContext):

    is_not_sub = await check_subscription(callback_query.from_user.id, callback_query.message) 
    if is_not_sub:
        return   
    async with state.proxy() as data:
        data['message_id'] = callback_query.message.message_id
    user_id = callback_query.from_user.id
    async with aiosqlite.connect("database.db") as db:
        async with db.execute("SELECT balance FROM users WHERE id=?", (user_id,)) as cursor:
            row = await cursor.fetchone()
            if row and row[0] < 3:
                await callback_query.answer("✖️ На вашем балансе недостаточно средств (мин вывод 3$)", show_alert=True)
                return
    await WithdrawState.amount.set()

    await bot.edit_message_caption(callback_query.message.chat.id, callback_query.message.message_id, caption="Введите сумму для вывода (баланс должен быть больше 3$)\n\nВыплаты происходят в @CryptoBot вы обязательно должны быть зарегистрированы", reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("❌ Отмена", callback_data="cancel_operation")))

@dp.message_handler(state=WithdrawState.amount)
async def process_amount(message: types.Message, state: FSMContext):
    amount = message.text
    try:
        amount = float(amount)
        if amount < 3:
            await message.answer_photo("https://0x0.st/s/WLsDgrn5ICAQ3kqNoNEuhw/HF2V.jpg", caption="✖️ Сумма должна быть больше 3$", reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("❌ Отмена", callback_data="cancel_operation")))
            return
    except ValueError:
        await message.answer_photo("https://0x0.st/s/WLsDgrn5ICAQ3kqNoNEuhw/HF2V.jpg", caption="✖️ Введите число", reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("❌ Отмена", callback_data="cancel_operation")))
        return

    async with aiosqlite.connect("database.db") as db:
        async with state.proxy() as data:
            user_id = message.from_user.id
            async with db.execute("SELECT balance FROM users WHERE id=?", (user_id,)) as cursor:
                row = await cursor.fetchone()
                if row and row[0] >= amount:
                    await update_balance(user_id, -amount)
                    await db.execute("INSERT INTO vivods (user_id, summ, is_done, username) VALUES (?, ?, 0, ?)", (user_id, amount, message.from_user.username,))
                    await db.commit()
                    await message.answer(f"✔️ Запрос на вывод {amount}$ отправлен на обработку", reply_markup=menu_markup)
                else:
                    await message.answer_photo("https://0x0.st/s/WLsDgrn5ICAQ3kqNoNEuhw/HF2V.jpg", caption="✖️ На вашем балансе недостаточно средств", reply_markup=InlineKeyboardMarkup().add(InlineKeyboardButton("❌ Отмена", callback_data="cancel_operation")))


    await state.finish()

@dp.callback_query_handler(lambda query: query.data == 'profile', state="*")
async def show_profile_info(query: types.CallbackQuery, state: FSMContext):
    await state.finish()
    user_id = query.from_user.id
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    username = query.from_user.username  # Получаем юзернейм пользователя

    async with aiosqlite.connect("database.db") as db:
        # Получаем данные о пользователе из базы данных
        async with db.execute("SELECT id, registration_time, balance FROM users WHERE id = ?", (user_id,)) as cursor:
            user_data = await cursor.fetchone()

            if user_data:
                user_id = user_data[0]
                registration_time = datetime.strptime(user_data[1], "%Y-%m-%d %H:%M:%S").strftime("%d.%m.%Y")  # Форматируем дату
                balance = user_data[2]

                caption = f"<b>Профиль пользователя:</b>\n\n" \
                          f"<b>ID:</b> {user_id}\n" \
                          f"<b>Username:</b> @{username}\n" \
                          f"<b>Дата регистрации:</b> {registration_time}\n" \
                          f"<b>Баланс:</b> {round(float(balance), 3)}$"

                # Создаем встроенные кнопки
                keyboard = types.InlineKeyboardMarkup(row_width=2)



                buttons = [
                    types.InlineKeyboardButton("💳 Вывод", callback_data="withdraw"),
                    types.InlineKeyboardButton("📤 Пополнить баланс", callback_data="top_up"),
                    types.InlineKeyboardButton("👥 Реферальная система", callback_data="refferal"),
                    types.InlineKeyboardButton("🏷️ Активировать промокод", callback_data="promo"),
                    types.InlineKeyboardButton("📊 Личная статистика", callback_data="userlichstata"),

                    
                ]
                keyboard.add(*buttons)
                keyboard.add(types.InlineKeyboardButton("⬅️ Назад", callback_data="back_to_menu"))

                await query.message.edit_media(
                    media=InputMediaPhoto(media="https://0x0.st/s/WLsDgrn5ICAQ3kqNoNEuhw/HF2V.jpg"),

                )

                await query.message.edit_caption(
                    caption=caption,
                    reply_markup=keyboard

                )
            else:
                await query.message.answer("Данные о пользователе не найдены.")

@dp.callback_query_handler(lambda query: query.data == 'userlichstata')
async def notgame(query: types.CallbackQuery):
    await query.answer("📆 Скоро появится...", show_alert=True)


@dp.callback_query_handler(lambda query: query.data == 'top_up')
async def back_to_menu(query: types.CallbackQuery):
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    # Функция обработки нажатия на кнопку "Назад" для возврата к меню
    menu_button_game = InlineKeyboardButton('Cryptobot 💲', callback_data='cryptobot')
    menu_button_profile = InlineKeyboardButton('⬅️ Назад', callback_data='back_to_menu')
    inline_markup = InlineKeyboardMarkup().add(
         menu_button_game
    ).row(
        menu_button_profile,
    )
    await query.message.edit_caption(caption="Меню", reply_markup=inline_markup)

@dp.callback_query_handler(lambda c: c.data == 'cryptobot', state='*')
async def crypto_bot_pay(call: types.CallbackQuery, state: FSMContext):
    edit_message_caption_text = f'<b>{hlink("⚜️ CryptoBot", "https://t.me/CryptoBot")}</b>\n\n' \
                                '— Минимум: <b>2$</b>\n\n' \
                                f'<b>💸 Введите сумму пополнения в USDT</b>'

    await bot.edit_message_caption(
        chat_id=call.from_user.id,
        message_id=call.message.message_id,
        caption=edit_message_caption_text,
        parse_mode='HTML',
        reply_markup=cancel_k
    )
    await call.answer()
    await CryproBot.sum.set()
    await state.update_data(message_id=call.message.message_id)


def crypto_bot_currencies_kb():
    currencies = ['USDT', 'USDC', 'BTC', 'ETH', 'TON', 'BNB']
    markup = InlineKeyboardMarkup(row_width=3)
    for currency in currencies:
        markup.insert(
            InlineKeyboardButton(
                text=currency,
                callback_data=f'crypto_bot_currency|{currency}'
            )
        )
    markup.add(
        InlineKeyboardButton(
            text='❌ Отменить действие',
            callback_data='cancel_operation'
        )
    )
    return markup

@dp.message_handler(state=CryproBot.sum)
async def crypto_bot_sum(message: types.Message, state: FSMContext):
    try:
        if float(message.text) >= 2:
            data = await state.get_data()
            message_id = data.get('message_id')
            edit_message_caption_text = f'<b>{hlink("⚜️ CryptoBot", "https://t.me/CryptoBot")}</b>\n\n' \
                                        f'— Сумма: <b>{message.text} USDT</b>\n\n' \
                                        '<b>💸 Выберите валюту, которой хотите оплатить счёт</b>'


            # Отправляем новое сообщение с фото, подписью и кнопками
            await message.answer_photo(
                photo="https://0x0.st/s/InYSWtSktQsT_c1SiwknuQ/HF2f.jpg",
                caption=edit_message_caption_text,
                reply_markup=crypto_bot_currencies_kb()
            )
            await bot.delete_message(chat_id=message.chat.id, message_id=message_id)

            await state.update_data(crypto_bot_sum=float(message.text))
            await CryproBot.currency.set()
        else:
            await message.answer(
                '<b>⚠️ Минимум: 2$!</b>'
            )
    except ValueError:
        await message.answer(
            '<b>❗️Сумма для пополнения должна быть в числовом формате!</b>'
        )

async def get_crypto_bot_sum(summa: float, currency: str):
    cryptopay = AioCryptoPay(CRYPTO_PAY_TOKEN)
    courses = await cryptopay.get_exchange_rates()
    await cryptopay.close()
    for course in courses:
        if course.source == currency and course.target == 'USD':
            return summa / course.rate



@dp.callback_query_handler(lambda c: c.data.startswith('crypto_bot_currency'), state=CryproBot.currency)
async def crypto_bot_currency(call: types.CallbackQuery, state: FSMContext):
    try:
        data = await state.get_data()
        amount = await get_crypto_bot_sum(data['crypto_bot_sum'], call.data.split('|')[1])
        cryptopay = AioCryptoPay(CRYPTO_PAY_TOKEN)
        invoice = await cryptopay.create_invoice(
            asset=call.data.split('|')[1],
            amount=amount)
        await cryptopay.close()
        await state.update_data(crypto_bot_currency=call.data.split('|')[1])
        await add_new_payment(invoice.invoice_id, data['crypto_bot_sum'])

        edit_message_caption_text = f'<b>💸 Отправьте {round(amount, 3)} {call.data.split("|")[1]} {hlink("по ссылке", invoice.bot_invoice_url)}</b>'


        await bot.edit_message_caption(
            chat_id=call.from_user.id,
            message_id=call.message.message_id,
            caption=edit_message_caption_text,
            parse_mode='HTML',
            reply_markup=check_crypto_bot_kb(invoice.bot_invoice_url, invoice.invoice_id)
        )

        await state.reset_state(with_data=False)
    except Exception as e:
        await call.message.answer(
            '<b>⚠️ Произошла ошибка!</b>'
        )
        print(e)

def check_crypto_bot_kb(url: str, invoice_hash: int):
    markup = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text='🔗 Оплатить',
                    url=url
                )
            ],
            [
                InlineKeyboardButton(
                    text='♻️ Проверить оплату',
                    callback_data=f'check_crypto_bot|{invoice_hash}'
                )
            ],

        ]
    )
    return markup


@dp.callback_query_handler(lambda c: c.data.startswith('check_crypto_bot'), state='*')
async def check_crypto_bot(call: types.CallbackQuery):
    payment = await select_payment(int(call.data.split('|')[1]))
    if payment:
        if await check_crypto_bot_invoice(int(call.data.split('|')[1])):
            await delete_payment(int(call.data.split('|')[1]))
            async with aiosqlite.connect("database.db") as db:
                async with db.execute("SELECT deposit_fee FROM config WHERE id = 1") as cursor:
                    config = await cursor.fetchone()
                    deposit_fee = config[0]
                    amount_after_fee = payment[2] - (payment[2] * deposit_fee / 100)
                    amount_after_fee = round(amount_after_fee, 3)

            await bot.edit_message_caption(
                chat_id=call.from_user.id,
                message_id=call.message.message_id,
                caption=f"<b>💸 Ваш баланс пополнен на сумму {amount_after_fee}$! (с учетом коммисии)</b>",
                parse_mode='HTML')


            for ADMIN in ADMINS:
                await call.bot.send_message(
                    ADMIN,
                    f'<b>{hlink("⚜️ CryptoBot", "https://t.me/CryptoBot")}</b>\n'
                    f'<b>💸 Обнаружено пополнение от @{call.from_user.username} [<code>{call.from_user.id}</code>] '
                    f'на сумму {payment[2]} $!\nС коммисией {amount_after_fee}</b>'
                    )
            await call.answer(
                '✅ Оплата прошла успешно!',
                show_alert=True
            )
            await update_balance(call.from_user.id, amount_after_fee)

        else:
            await call.answer(
                '❗️ Вы не оплатили счёт!',
                show_alert=True
            )

async def check_crypto_bot_invoice(invoice_id: int):
    cryptopay = AioCryptoPay(CRYPTO_PAY_TOKEN)
    invoice = await cryptopay.get_invoices(invoice_ids=invoice_id)
    await cryptopay.close()
    if invoice.status == 'paid':
        return True
    else:
        return False



@dp.callback_query_handler(lambda query: query.data == 'info')
async def show_information(query: types.CallbackQuery):
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    chat_link = "https://t.me/BestUpX"
    admin_link = "https://t.me/Qumati"
    rules_link = "https://t.me/example"

    button_chat = InlineKeyboardButton('👥 Чат', url=chat_link)
    button_admin = InlineKeyboardButton('👮‍♂️ Администратор', url='https://t.me/Qumati')
    button_rules = InlineKeyboardButton('📜 Правила', url=rules_link)
    button_channel = InlineKeyboardButton('🎲 Канал', url="https://t.me/chat")

    button_back = InlineKeyboardButton('⬅️ Назад', callback_data='back_to_menu')
    
    inline_markup = InlineKeyboardMarkup().add(
        button_admin
    ).add(
        button_chat
    ).add(
        button_channel
    )


    inline_markup.add(
        button_back
    )
    await query.message.edit_media(
        media=InputMediaPhoto(media="https://0x0.st/s/8eLgxx3oIwD29YDvTAKjsg/HF24.jpg"),
    )
    await query.message.edit_caption(
        caption="Информация",
        reply_markup=inline_markup
    )

class PromoState(StatesGroup):
    waiting_for_promo = State()

@dp.callback_query_handler(lambda query: query.data == 'promo')
async def show_refferal(query: types.CallbackQuery, state: FSMContext):
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    await PromoState.waiting_for_promo.set()
    
    button_back = InlineKeyboardButton('⬅️ Назад', callback_data='profile')
    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    inline_markup.add(button_back)
    
    message = await query.message.edit_media(media=InputMediaPhoto(media="https://0x0.st/s/HhaROStlw11bykWK7yVynw/HCDj.jpg"))
    
    caption = f"""<b>🎁 Введите ваш промокод</b>"""
    await query.message.edit_caption(caption=caption, reply_markup=inline_markup)
    
    await PromoState.waiting_for_promo.set()
    await state.update_data(message_id=message.message_id)

async def get_database_connection():
    return await aiosqlite.connect("database.db")

@dp.message_handler(state=PromoState.waiting_for_promo)
async def process_promo_code(message: types.Message, state: FSMContext):
    button_back = InlineKeyboardButton('⬅️ Назад', callback_data='profile')
    inline_markup = types.InlineKeyboardMarkup(row_width=1)
    inline_markup.add(button_back)
    async with state.proxy() as data:
        data['promo_code'] = message.text
        original_message_id = data.get('message_id')
        # Проверка промокода в базе данных promo
        db = await get_database_connection()
        cursor = await db.execute("SELECT * FROM promo WHERE name = ?", (data['promo_code'],))
        promo_data = await cursor.fetchone()
        if promo_data:
            cursor = await db.execute("SELECT COUNT(*) FROM activate_promo WHERE id_promo = ?", (promo_data[0],))
            activations_count = await cursor.fetchone()
            if activations_count[0] >= promo_data[3]:
                await bot.delete_message(message.chat.id, message.message_id)
                await bot.delete_message(message.chat.id, original_message_id)
                await message.answer_photo(
                    photo="https://0x0.st/s/HhaROStlw11bykWK7yVynw/HCDj.jpg",
                    caption="✖️ У промокода закончился лимит активаций",
                    reply_markup=inline_markup
                )
                await db.close()
                await state.finish()
                return

            # Проверка, активировал ли пользователь уже этот промокод
            cursor = await db.execute("SELECT * FROM activate_promo WHERE id_promo = ? AND id_user = ?", (promo_data[0], message.from_user.id))
            already_activated = await cursor.fetchone()
            
            if not already_activated:
                # Добавление баланса пользователю и запись в activate_promo
                await db.execute("INSERT INTO activate_promo (id_promo, id_user) VALUES (?, ?)", (promo_data[0], message.from_user.id))
                # Здесь добавьте логику для добавления баланса пользователю
                
                await db.commit()

                
                data = await state.get_data()

                
                if original_message_id:
                    try:
                        await bot.delete_message(message.chat.id, message.message_id)
                        await bot.edit_caption(
                            chat_id=message.chat.id,
                            message_id=original_message_id, 
                            caption="☑️ Промокод успешно активирован!",
                            reply_markup=inline_markup
                        )
                    except:
                        await bot.delete_message(message.chat.id, original_message_id)
                        await message.answer_photo(
                            photo="https://0x0.st/s/HhaROStlw11bykWK7yVynw/HCDj.jpg",
                            caption="☑️ Промокод успешно активирован!",
                            reply_markup=inline_markup
                         )

                    await update_balance(message.from_user.id, promo_data[2])


            else:
                await bot.delete_message(message.chat.id, message.message_id)
                await bot.delete_message(message.chat.id, original_message_id)

                await message.answer_photo(
                    photo="https://0x0.st/s/HhaROStlw11bykWK7yVynw/HCDj.jpg",
                    caption="✖️ Вы уже активировали данный промокод",
                    reply_markup=inline_markup
                )

        else:
            await bot.delete_message(message.chat.id, message.message_id)
            await bot.delete_message(message.chat.id, original_message_id)

            await message.answer_photo(
                photo="https://0x0.st/s/HhaROStlw11bykWK7yVynw/HCDj.jpg",
                caption="✖️ Промокод не найден",
                reply_markup=inline_markup
            )
    await db.close()
    await state.finish()

@dp.callback_query_handler(lambda query: query.data == 'refferal')
async def show_refferal(query: types.CallbackQuery):
    is_not_sub = await check_subscription(query.from_user.id, query.message) 
    if is_not_sub:
        return   

    button_back = InlineKeyboardButton('⬅️ Назад', callback_data='profile')
    inline_markup= types.InlineKeyboardMarkup(row_width=1)

    inline_markup.add(
        button_back
    )
    await query.message.edit_media(
        media=InputMediaPhoto(media="https://0x0.st/s/puKcwymiksJuvhhR8ZmkNA/HCGF.jpg"),
    )
    async with aiosqlite.connect("database.db") as db:
        cursor = await db.execute("SELECT COUNT(id) FROM users WHERE reffer_id = ?", (query.from_user.id,))
        count = await cursor.fetchone()
    me = await bot.get_me()
    caption = f"""<b>
👥 Реферальная система

👤 Кол-во рефералов: {count[0]}
	
— За каждую игру Вашего реферала - Вы будете получать 1% от суммы каждой ставки

🔗 Ваша реферальная ссылка
<code>https://t.me/{me.username}?start={query.from_user.id}</code></b>
"""
    await query.message.edit_caption(
        caption=caption,
        reply_markup=inline_markup
    )


@dp.callback_query_handler(lambda query: query.data == 'notgames')
async def notgame(query: types.CallbackQuery):
    await query.answer("❌ Здесь нет игр", show_alert=True)

print("Dev: @MusyaNorm")

if __name__ == '__main__':
    
    async def on_startup(dp):
        await create_tables()

    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)